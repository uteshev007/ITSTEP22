//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by modelessDlg.rc
//
#define IDC_MYICON                      2
#define IDD_MODELESSDLG_DIALOG          102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_MODELESSDLG                 107
#define IDI_SMALL                       108
#define IDC_MODELESSDLG                 109
#define IDR_MAINFRAME                   128
#define IDD_MODELESS                    129
#define IDC_RED                         1003
#define IDC_GREEN                       1004
#define IDC_SCROLLBAR3                  1005
#define IDC_BLUE                        1005
#define IDC_GREEN2                      1005
#define ID_DIALOG_SHOW                  32771
#define ID_DIALOG_HIDE                  32772
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
