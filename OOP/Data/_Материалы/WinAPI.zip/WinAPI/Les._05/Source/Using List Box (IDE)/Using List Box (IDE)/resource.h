//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Using List Box (IDE).rc
//
#define IDD_DIALOG1                     101
#define IDC_LIST1                       1001
#define IDC_LIST2                       1002
#define IDC_ADD                         1003
#define IDC_EDIT1                       1004
#define IDC_DEL                         1005
#define IDC_FIND                        1006
#define IDC_EDIT2                       1007
#define IDC_DELALL                      1008
#define IDC_BUTTON1                     1009
#define IDC_GETSELITEMS                 1009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
