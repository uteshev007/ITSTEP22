// Test_CS.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <windows.h>


CRITICAL_SECTION  g_CS;

int N=0;

DWORD WINAPI  FirstThread (void*)
{
	EnterCriticalSection(&g_CS);
	int M=N;
	M++;
	N=M; 
	LeaveCriticalSection(&g_CS);
	return 0;
}

DWORD WINAPI  SecondThread (void*)
{
	EnterCriticalSection(&g_CS);
	int M=N;
	M++;
	N=M; 
	LeaveCriticalSection(&g_CS);
	return 0;
}



int _tmain(int argc, _TCHAR* argv[])
{
	InitializeCriticalSection(&g_CS);

	DWORD dwTFId,dwTSId;

	CreateThread(NULL, 0, FirstThread, NULL, 0, &dwTFId);
	CreateThread(NULL, 0, FirstThread, NULL, 0, &dwTSId);

	DeleteCriticalSection(&g_CS);

	return 0;
}

