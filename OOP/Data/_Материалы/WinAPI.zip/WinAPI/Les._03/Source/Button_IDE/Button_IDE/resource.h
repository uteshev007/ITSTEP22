//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Button_IDE.rc
//
#define IDD_DIALOG1                     101
#define IDB_BITMAP1                     102
#define IDB_BITMAP2                     103
#define IDB_BITMAP3                     104
#define IDB_BITMAP4                     105
#define IDB_BITMAP5                     106
#define IDC_START                       1001
#define IDC_BUTTON2                     1002
#define IDC_STOP                        1002
#define IDC_PICTURE                     1003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
