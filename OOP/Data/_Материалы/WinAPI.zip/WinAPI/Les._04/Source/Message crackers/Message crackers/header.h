#pragma once
#include <windows.h>
#include <WindowsX.h>
#include "resource.h"
