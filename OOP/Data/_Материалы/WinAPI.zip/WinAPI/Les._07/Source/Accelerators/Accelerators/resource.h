//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Accelerators.rc
//
#define IDD_DIALOG1                     101
#define IDR_MENU1                       102
#define IDR_ACCELERATOR1                103

#define IDM_NEW                         40015
#define IDM_OPEN                        40016
#define IDM_SAVE                        40017
#define IDM_SAVE_AS                     40018
#define IDM_PAGESETUP                   40019
#define IDM_PRINT                       40020
#define IDM_QUIT                        40021

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40022
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
