//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Menu.rc
//
#define IDD_DIALOG1                     101
#define IDR_MENU1                       102
#define IDR_MENU2                       103
#define IDC_EDIT1                       1001
#define ID_40001                        40001
#define ID_40002                        40002
#define ID_40003                        40003
#define ID_40004                        40004
#define ID_40005                        40005
#define ID_40006                        40006
#define ID_UNDO                         40007
#define ID_CUT                          40008
#define ID_COPY                         40009
#define ID_PASTE                        40010
#define ID_DEL                          40011
#define ID_SELECTALL                    40012
#define ID_40013                        40013
#define ID_STATUSBAR                    40014

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40015
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
