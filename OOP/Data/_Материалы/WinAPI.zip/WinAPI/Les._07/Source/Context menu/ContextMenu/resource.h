//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ContextMenu.rc
//
#define IDD_DIALOG1                     101
#define IDR_MENU1                       102
#define IDC_BUTTON1                     1001
#define IDC_EDIT1                       1002
#define IDC_BUTTON2                     1003
#define IDC_EDIT2                       1004
#define IDC_CHECK1                      1007
#define IDC_CHECK2                      1008
#define ID_GROUP1_BUTTON                40003
#define ID_GROUP1_EDIT                  40004
#define ID_GROUP1_CHECKBOX              40005
#define ID_GROUP2_BUTTON                40006
#define ID_GROUP2_EDIT                  40007
#define ID_GROUP2_CHECKBOX              40008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40013
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
