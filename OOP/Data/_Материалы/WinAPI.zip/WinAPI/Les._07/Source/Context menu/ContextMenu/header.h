#pragma once
#include <windows.h>
#include <windowsX.h>
#include "resource.h"

