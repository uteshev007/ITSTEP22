#pragma once
#include <windows.h>
#include <windowsX.h>
#include <commctrl.h>
#include "resource.h"

#pragma comment(lib,"comctl32")

#define MIN 0
#define MAX 400