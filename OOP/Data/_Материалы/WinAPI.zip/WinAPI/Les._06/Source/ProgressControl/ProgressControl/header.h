#pragma once
#include <windows.h>
#include <windowsX.h>
#include <ctime>
#include <commctrl.h>
#include "resource.h"

#pragma comment(lib,"comctl32")