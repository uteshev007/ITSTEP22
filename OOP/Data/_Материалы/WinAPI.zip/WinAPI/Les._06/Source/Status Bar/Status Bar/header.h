#pragma once
#include <windows.h>
#include <windowsX.h>
#include <commctrl.h>
#include "resource.h"

#pragma comment(lib,"comctl32")
