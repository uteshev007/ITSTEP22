// FirstDllExe.cpp : Defines the entry point for the console application.
//


#include "stdafx.h"

typedef void (WINAPI*cfunc)(); 

cfunc Test1;
cfunc Test2;


int _tmain(int argc, _TCHAR* argv[])
{

	HINSTANCE hLib=LoadLibrary( _T("FirstDll.dll"));
    if(hLib==NULL) 
    {
       printf( "Unable to load library!");
       
       return -1;
    } 

	
    Test1=(cfunc)GetProcAddress((HMODULE)hLib, "Test1");
    Test2=(cfunc)GetProcAddress((HMODULE)hLib, "Test2");


	Test1();
	Test2();

	FreeModule(hLib);

	return 0;
}

