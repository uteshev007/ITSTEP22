// FirstDllExe.cpp : Defines the entry point for the console application.
//


#include "stdafx.h"
#pragma comment (lib, "FirstDll.lib");

extern "C" __declspec(dllexport) void Test1();
extern "C" __declspec(dllexport) void Test2();

int _tmain(int argc, _TCHAR* argv[])
{
	Test1();
	Test2();

	return 0;
}

