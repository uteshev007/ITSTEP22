// TestProcess.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"


int _tmain(int argc, _TCHAR* argv[])
{

	HANDLE stdOutputHandle;
	HANDLE stdReadHandle;
	CreatePipe(&stdOutputHandle, &stdReadHandle, NULL, 100); 




	STARTUPINFO si;
    PROCESS_INFORMATION pi;

	

    ZeroMemory( &si, sizeof(si) );
    ZeroMemory( &pi, sizeof(pi) );

	si.cb = sizeof(si);
	
	si.dwX=100;
	si.dwY=10;
	si.dwXSize=25;
	si.dwYSize=40;
	si.dwXCountChars=300;
	si.dwYCountChars=80;
	si.dwFillAttribute=0x1E;

	si.dwFlags=STARTF_USECOUNTCHARS | STARTF_USEPOSITION | STARTF_USEFILLATTRIBUTE | STARTF_USEPOSITION;

   

     
	CreateProcess(L"C:\\windows\\system32\\cmd.exe",L"",//L"C:\\Program Files\\FAR\\far.exe",
	
        NULL,           // Process handle not inheritable
        NULL,           // Thread handle not inheritable
        TRUE,          // Set handle inheritance to FALSE
		CREATE_NEW_CONSOLE | REALTIME_PRIORITY_CLASS,// No creation flags
        NULL,           // Use parent's environment block
        NULL,           // Use parent's starting directory 
        &si,            // Pointer to STARTUPINFO structure
        &pi );           // Pointer to PROCESS_INFORMATION structure
    
         
    

    // Wait until child process exits.
    WaitForSingleObject( pi.hProcess, INFINITE );

    // Close process and thread handles. 
    CloseHandle( pi.hProcess );
    CloseHandle( pi.hThread );

	return 0;
}

