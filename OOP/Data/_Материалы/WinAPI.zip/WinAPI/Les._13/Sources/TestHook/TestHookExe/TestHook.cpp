#include "stdafx.h"
#include "resource.h"

#pragma comment (lib, "..\\debug\\testhookdll.lib")
#define UWM_MYHOOK_MSG _T("UMW_MYHOOK-{B33523250-D235D-1152334-A523B-0060567718D04}")


__declspec(dllexport) BOOL WINAPI setMyHook(HWND hWnd);
__declspec(dllexport) BOOL clearMyHook(HWND hWnd);

INT_PTR CALLBACK MyDialogProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam);
INT WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, INT);

void OnCommand(HWND hwnd, int id, HWND hwndCtl, UINT codeNotify);
BOOL OnInitDialog(HWND hwnd, HWND hwndFocus, LPARAM lParam);
UINT UWM_MYTESTHOOK;

LRESULT OnMouseHook(HWND hDlg, WPARAM wParam, LPARAM lParam)
{
	TCHAR strWParam[50];
	TCHAR strLParam[50];
	TCHAR strScan[20];
	_stprintf_s(strWParam, 50, _T("wParam(VirtualCode) =%u (%c)"), wParam, wParam); 
	_stprintf_s(strLParam, 50, _T("lParam=%u"), lParam); 
	_stprintf_s(strScan, 20, _T("ScanCode=%u"), (lParam&0x7F8000)>>16); 
	SetWindowText(GetDlgItem(hDlg, IDC_EDIT1), strWParam);
	SetWindowText(GetDlgItem(hDlg, IDC_EDIT2), strLParam);
	SetWindowText(GetDlgItem(hDlg, IDC_EDIT3), strScan);
	return 0;
}




INT_PTR CALLBACK MyDialogProc(HWND hDlg, UINT Msg, WPARAM wParam, LPARAM lParam)
{
	switch(Msg)
	{

		HANDLE_MSG(hDlg, WM_COMMAND, OnCommand);
		HANDLE_MSG(hDlg, WM_INITDIALOG, OnInitDialog);       
		
		
	}

	if(UWM_MYTESTHOOK==Msg)
		return OnMouseHook(hDlg, wParam, lParam);


	return 0;
}



INT WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrevInst, LPSTR strCmdLine, INT nCmdShow)
{


	UWM_MYTESTHOOK = ::RegisterWindowMessage(UWM_MYHOOK_MSG);

	INITCOMMONCONTROLSEX InitCtrls;
	InitCtrls.dwSize = sizeof(InitCtrls);
	InitCtrls.dwICC = ICC_WIN95_CLASSES;
	InitCommonControlsEx(&InitCtrls);
	
	
	DialogBox(hInst, MAKEINTRESOURCE(IDD_DIALOG1), NULL, MyDialogProc); 



	return 0;
}



void OnCommand(HWND hDlg, int id, HWND hwndCtl, UINT codeNotify)
{
	switch(id)
	{
	case IDC_BUTTON1:
		setMyHook(hDlg);
		break;
	case IDC_BUTTON2:
		clearMyHook(hDlg);
		break;

	case IDCANCEL:
		EndDialog(hDlg, 0);
		clearMyHook(hDlg);
		break;	
	
	}

}


BOOL OnInitDialog(HWND hDlg, HWND hwndFocus, LPARAM lParam)
{
	
	SetWindowPos(hDlg, HWND_TOPMOST, 0,0,0,0, SWP_NOMOVE | SWP_NOSIZE);
	setMyHook(hDlg);
	return FALSE;
}

		


