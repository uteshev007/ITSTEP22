#pragma once




#define UWM_MYHOOK_MSG _T("UMW_MYHOOK-{B33523250-D235D-1152334-A523B-0060567718D04}")


__declspec(dllexport) BOOL clearMyHook(HWND hWnd);
__declspec(dllexport) BOOL WINAPI setMyHook(HWND hWnd);
