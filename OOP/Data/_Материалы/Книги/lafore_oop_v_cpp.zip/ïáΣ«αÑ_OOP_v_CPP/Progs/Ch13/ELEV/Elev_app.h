// elev_app.h
// provides constants to specify building characteristics

const int NUM_FLOORS = 20;   //number of floors
const int NUM_CARS = 4;      //number of elevator cars